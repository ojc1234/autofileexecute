﻿// See https://aka.ms/new-console-template for more information
using System;
using System.IO;
using System.Diagnostics;
namespace Solution1
{
    class Solution
    {
        public static void Main()
        {
            Console.WriteLine("저희 백터 프로그램은 파일을 찾아주는 기능과 파일을 연결해주는 기능과 파일이 몇 개 있는지 알려주는 기능을 포함하고 있습니다." +
                "we have the bactor program is 3 function own, file find and file connect and file is what numble each else announce contain the three functions.");
            string read = Console.ReadLine();
            string[] dirs = null;
            try
            {
                string[] files = Directory.GetFiles(@read, "*");
                dirs = Directory.GetDirectories(@read, "*", SearchOption.TopDirectoryOnly);
                var list = new List<string>();
                list.AddRange(files);
                list.AddRange(dirs);
                dirs = list.ToArray();
                var loop = 1;
                foreach (string dir in dirs)
                {

                    Console.WriteLine(loop+". " + dir);
                    loop++;
                }
            }
            catch (Exception e)
            {

                Console.WriteLine("파일찾기 에러");
            }
            Console.WriteLine("So that you can find the file in the this program!");
            Console.WriteLine("start letter");
            string startnum = Console.ReadLine();
            int startnumint = Convert.ToInt32(startnum);
            Console.WriteLine(startnumint);
            Process.Start(new ProcessStartInfo(@dirs[startnumint-1]) { UseShellExecute = true });
            //Process.Start(@dirs[startnumint]);
        }
    }
        
    }